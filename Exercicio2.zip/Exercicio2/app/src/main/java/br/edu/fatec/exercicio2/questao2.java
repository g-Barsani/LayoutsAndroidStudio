package br.edu.fatec.exercicio2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class questao2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.questao2);

        Button btnResponder = findViewById(R.id.btnResponder);
        btnResponder.setOnClickListener(this::Responder);
    }

    public void Responder (View view) {
        // TODO: Implementar a resposta do botão
        // Ir para próxima tela
        Intent intent = new Intent(questao2.this, questao3.class);
        startActivity(intent);
    }
}