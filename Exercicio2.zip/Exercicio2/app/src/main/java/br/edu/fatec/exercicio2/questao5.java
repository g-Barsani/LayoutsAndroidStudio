package br.edu.fatec.exercicio2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class questao5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.questao5);


        Button btnResponder = findViewById(R.id.btnResponder);
        btnResponder.setOnClickListener(this::Responder);
    }

    public void Responder (View view) {
        Toast.makeText(getApplicationContext(), "fim", Toast.LENGTH_SHORT).show();

        finish();
    }
}