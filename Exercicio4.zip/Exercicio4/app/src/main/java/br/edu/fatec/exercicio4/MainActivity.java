package br.edu.fatec.exercicio4;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumberDecimal1, editTextNumberDecimal2, editTextNumber;
    private TextView valorPorPessoa, contaTotal;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch taxaDeServico;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        Button checkoutBtn = findViewById(R.id.checkoutBtn);

        editTextNumberDecimal1 = findViewById(R.id.editTextNumberDecimal1);
        editTextNumberDecimal2 = findViewById(R.id.editTextNumberDecimal2);
        editTextNumber = findViewById(R.id.editTextNumber);
        taxaDeServico = findViewById(R.id.taxaDeServico);
        valorPorPessoa = findViewById(R.id.valorPorPessoa);
        contaTotal = findViewById(R.id.contaTotal);


        checkoutBtn.setOnClickListener(this::checkout);
    }

    public void checkout(View view) {
        double consumoTotal = 0;
        double couverArtistico = 0;
        int dividirContaPor = 0;

// Retrieve text from EditText fields and trim any extra spaces
        String textconsumoTotal = editTextNumberDecimal1.getText().toString().trim();
        String textcouverArtistico = editTextNumberDecimal2.getText().toString().trim();
        String textdividirContaPor = editTextNumber.getText().toString().trim();


        if (!textconsumoTotal.isEmpty()) {
            consumoTotal = Double.parseDouble(textconsumoTotal); // Correctly assign to consumoTotal
        }
        if (taxaDeServico.isChecked()) {
            consumoTotal += consumoTotal * 0.1;
        }
        if (!textcouverArtistico.isEmpty()) {
            couverArtistico = Double.parseDouble(textcouverArtistico); // Correctly assign to couverArtistico
            consumoTotal += couverArtistico;
        }
        if (!textdividirContaPor.isEmpty()) {
            dividirContaPor = Integer.parseInt(textdividirContaPor); // Correctly assign to dividirContaPor
        }

        Toast.makeText(this, "TOTAL: "
                        + ((consumoTotal)
                        + (couverArtistico)),
                Toast.LENGTH_SHORT).show();

        valorPorPessoa.setText(String.valueOf(consumoTotal/dividirContaPor));
        contaTotal.setText(String.valueOf(consumoTotal));


    }
}